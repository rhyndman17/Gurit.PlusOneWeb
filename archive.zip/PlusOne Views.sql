USE [HMAUD]
GO

/****** Object:  View [dbo].[PlusOneGL3]    Script Date: 1/29/2026 10:39:12 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


create view [dbo].[PlusOneGL3] as

select LandedCostCode from hmlPOLandedCosts
GO

/****** Object:  View [dbo].[PlusOneGLM]    Script Date: 1/29/2026 10:39:12 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


create view [dbo].[PlusOneGLM] as

select rtrim(i.ACTNUMST) 'GLAccountCode' ,rtrim(g.ACTNUMBR_1) 'CodeGroup',rtrim(g.ACTNUMBR_2) 'CodeNumber',rtrim(g.ACTDESCR) 'CodeDescription',
case ACTIVE when 0 then 'Inactive' when 1 then 'Active' else 'Unknown' end as 'CodeStatus' 
from GL00100 g 
join GL00105 i on i.ACTINDX = g.ACTINDX 
where ACTIVE = 1 
GO

/****** Object:  View [dbo].[PlusOnePUR]    Script Date: 1/29/2026 10:39:12 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE   view [dbo].[PlusOnePUR] as

select 'GAP' 'PayerID',rtrim(ph.VENDORID) 'SupplierID',
cast(datepart(year,ph.DOCDATE) as char(4))+'-'+case when month(ph.DOCDATE)<10 then '0' else '' end+
	rtrim(cast(datepart(month,ph.DOCDATE) as char(2)))+'-'+case when day(ph.DOCDATE)<10 then '0' else '' end+
	rtrim(cast(datepart(day,ph.DOCDATE) as char(2))) 'DocumentDate',rtrim(ph.PONUMBER) 'PONumber','' 'HeaderRefNo',
			rtrim(USER2ENT) 'BuyerContact','' 'BuyerEmail' ,'Y' 'BuyerApproverPrev','' 'BuyerApproverNext',
			cast(pd.LineNumber as char(20)) 'LineNo',case when pd.POLNESTA in (4,5,6) then 'X' else '' end as 'LineRefNo1','Standard' 'LineRefNo2',rtrim(pd.ITEMNMBR) 'BuyerProductCode',
			rtrim(replace(pd.ITEMDESC,'"','')) 'ProductDescription',
			cast(pd.QTYORDER-pd.QTYCANCE as char(20)) 'OrderedQty',rtrim(pd.UOFM) 'OrderedQtyUOM',cast(pd.ORUNTCST as char(20)) 'NetPrice','1.00000' 'PerQty',
			cast(isnull(pq.QTYSHPPD,0) as char(20)) 'ReceivedQty', cast(isnull(pq.QTYINVCD,0) as char(20)) 'CostedQty', '' 'ReceivedValue', '' 'CostedValue',cast(pd.OREXTCST as char(20)) 'LineValueExclGST', 
			case when pd.ORTAXAMT > 0 then cast(cast(pd.ORTAXAMT/pd.OREXTCST as numeric(18,2)) as char(20)) else '0' end 'LineGSTRate',
			cast(pd.ORTAXAMT as char(20)) 'LineGSTValue',rtrim(ph.CURNCYID) 'Currency',pd.ORD

from POP10100 ph
join POP10110 pd on ph.PONUMBER=pd.PONUMBER
left join gurPOQtySummary pq on pd.PONUMBER=pq.PONUMBER and pd.ORD=pq.POLNENUM 
--left join hmlUserMaintenance um on ph.USER2ENT=um.[User ID]
where ph.POTYPE<>0 
GO

/****** Object:  View [dbo].[PlusOneSUP]    Script Date: 1/29/2026 10:39:12 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE view [dbo].[PlusOneSUP] as

select 
rtrim(v.VENDORID) 'SupplierID', rtrim(v.VENDSHNM) 'SupplierCrossRef', rtrim(v.VENDNAME) 'SupplierName', 
rtrim(v.ADDRESS1) 'SupplierAddressL1', rtrim(v.ADDRESS2) 'SupplierAddressL2',rtrim(v.ADDRESS3) 'SupplierAddressL3',
'' as 'SupplierAddressL4', rtrim(v.ZIPCODE) 'SupplierPostcode', rtrim(v.COUNTRY) 'SupplierCountry',
rtrim(v.VNDCNTCT) 'SupplierContact',rtrim(v.PHNUMBR1) 'SupplierPhone',rtrim(v.FAXNUMBR) 'SupplierFax', isnull(rtrim(i.INET1),'') 'SupplierEmail',
'' as 'PaymentMeans', rtrim(v.CURNCYID) 'Currency', '' as 'CurrencyDesc', '' as 'SupplierAccountName',
'' as 'SupplierBankName', '' as 'SupplierBankBranch', '' as 'SupplierAccountNo',rtrim(v.TXIDNMBR) as 'SupplierTaxID',rtrim(v.TAXSCHID) 'SupplierTaxCode',isnull(cast(t.TXDTLPCT as char(12)),'') 'SupplierTaxRate','' as 'SupplierNotes',
isnull(rtrim(g.ACTNUMST),'') 'SupplierDefaultCoding','Y' 'SupplierPOFlag'
from PM00200 v
left join SY01200 i on i.Master_ID=v.VENDORID and i.ADRSCODE=v.VADDCDPR
left join TX00201 t on t.TAXDTLID=v.TAXSCHID
left join GL00105 g on g.ACTINDX=v.PMPRCHIX
where v.VENDSTTS=1 and v.HOLD=0 and
		v.VENDORID in (select VENDORID from IV00103)
union
select 
rtrim(v.VENDORID) 'SupplierID', rtrim(v.VENDSHNM) 'SupplierCrossRef', rtrim(v.VENDNAME) 'SupplierName', 
rtrim(v.ADDRESS1) 'SupplierAddressL1', rtrim(v.ADDRESS2) 'SupplierAddressL2',rtrim(v.ADDRESS3) 'SupplierAddressL3',
'' as 'SupplierAddressL4', rtrim(v.ZIPCODE) 'SupplierPostcode', rtrim(v.COUNTRY) 'SupplierCountry',
rtrim(v.VNDCNTCT) 'SupplierContact',rtrim(v.PHNUMBR1) 'SupplierPhone',rtrim(v.FAXNUMBR) 'SupplierFax', isnull(rtrim(i.INET1),'') 'SupplierEmail',
'' as 'PaymentMeans', rtrim(v.CURNCYID) 'Currency', '' as 'CurrencyDesc', '' as 'SupplierAccountName',
'' as 'SupplierBankName', '' as 'SupplierBankBranch', '' as 'SupplierAccountNo',rtrim(v.TXIDNMBR) as 'SupplierTaxID',rtrim(v.TAXSCHID) 'SupplierTaxCode',isnull(cast(t.TXDTLPCT as char(12)),'') 'SupplierTaxRate','' as 'SupplierNotes',
isnull(rtrim(g.ACTNUMST),'') 'SupplierDefaultCoding','N' 'SupplierPOFlag'
from PM00200 v
left join SY01200 i on i.Master_ID=v.VENDORID and i.ADRSCODE=v.VADDCDPR
left join TX00201 t on t.TAXDTLID=v.TAXSCHID
left join GL00105 g on g.ACTINDX=v.PMPRCHIX
where v.VENDSTTS=1 and v.HOLD=0 and
		v.VENDORID not in (select VENDORID from IV00103)
GO


