<#
.SYNOPSIS
    Extract PlusOne source data files for upload.
.DESCRIPTION
    Runs configured PlusOne extracts for NZ or AU, writes CSV files into the local upload folder, and logs progress.
.NOTES
    Add future extracts in Get-ExtractionDefinitions.
#>

[CmdletBinding()]
param (
    [Parameter(Mandatory = $true, Position = 0)]
    [ValidateSet('NZ', 'AU')]
    [string]$Site,

    [string[]]$Extraction = @('All'),

    [datetime]$RunDate = (Get-Date),

    [switch]$WhatIf
)

$ErrorActionPreference = 'Stop'

function Write-Log {
    param (
        [Parameter(Mandatory = $true)]
        [string]$Message,

        [ValidateSet('INFO','WARN','ERROR')]
        [string]$Level = 'INFO'
    )

    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $entry = "[$timestamp] [$Level] $Message"
    Write-Host $entry
    if ($global:LogFilePath) {
        $entry | Out-File -FilePath $global:LogFilePath -Append -Encoding UTF8
    }
}

function Load-Config {
    $scriptDir = if ($PSCommandPath) { Split-Path -Parent $PSCommandPath } elseif ($PSScriptRoot) { $PSScriptRoot } elseif ($MyInvocation.MyCommand.Path) { Split-Path -Parent $MyInvocation.MyCommand.Path } else { throw 'Cannot determine script directory.' }
    $configFile = Join-Path $scriptDir 'PlusOneConfig.json'
    if (-not (Test-Path $configFile)) {
        throw "Configuration file not found: $configFile"
    }

    $json = Get-Content -Path $configFile -Raw | ConvertFrom-Json
    if (-not $json.Sites.$Site) {
        throw "Site '$Site' is not defined in configuration."
    }

    $siteConfig = $json.Sites.$Site
    $properties = @('LocalUploadPath', 'ExtractLogFilePath', 'UploadLogFilePath', 'LogFilePath', 'SqlConnectionString', 'SqlCommandTimeout')
    foreach ($prop in $properties) {
        while ($siteConfig.$prop -is [array]) {
            $siteConfig.$prop = $siteConfig.$prop[0]
        }
    }

    return $siteConfig
}

function Get-ExtractionDefinitions {
    return @(
        [pscustomobject]@{
            Name = 'GLM'
            Description = 'GL code master'
            Query = @"
select
    GLAccountCode,
    CodeGroup,
    CodeNumber,
    CodeDescription,
    CodeStatus
from PlusOneGLM
order by GLAccountCode
"@
            Columns = @(
                'GLAccountCode',
                'CodeGroup',
                'CodeNumber',
                'CodeDescription',
                'CodeStatus'
            )
            GetFileName = {
                param ([datetime]$date)
                return 'GLM-GAP-{0}.csv' -f $date.ToString('yyMMdd')
            }
        },
        [pscustomobject]@{
            Name = 'SUP'
            Description = 'Supplier master'
            Query = @"
select
    SupplierID,
    SupplierCrossRef as SuppierCrossRef,
    SupplierName,
    SupplierAddressL1,
    SupplierAddressL2,
    SupplierAddressL3,
    SupplierAddressL4,
    SupplierPostcode as SupplierPostCode,
    SupplierCountry,
    SupplierContact,
    SupplierPhone,
    SupplierFax,
    SupplierEmail,
    PaymentMeans,
    Currency,
    CurrencyDesc,
    SupplierAccountName,
    SupplierBankName,
    SupplierBankBranch,
    SupplierAccountNo,
    SupplierTaxID,
    SupplierTaxCode,
    SupplierTaxRate,
    SupplierNotes,
    SupplierDefaultCoding,
    SupplierPOFlag
from PlusOneSUP
order by SupplierID
"@
            Columns = @(
                'SupplierID',
                'SuppierCrossRef',
                'SupplierName',
                'SupplierAddressL1',
                'SupplierAddressL2',
                'SupplierAddressL3',
                'SupplierAddressL4',
                'SupplierPostCode',
                'SupplierCountry',
                'SupplierContact',
                'SupplierPhone',
                'SupplierFax',
                'SupplierEmail',
                'PaymentMeans',
                'Currency',
                'CurrencyDesc',
                'SupplierAccountName',
                'SupplierBankName',
                'SupplierBankBranch',
                'SupplierAccountNo',
                'SupplierTaxID',
                'SupplierTaxCode',
                'SupplierTaxRate',
                'SupplierNotes',
                'SupplierDefaultCoding',
                'SupplierPOFlag'
            )
            GetFileName = {
                param ([datetime]$date)
                return 'SUP-GAP-{0}.csv' -f $date.ToString('yyMMdd')
            }
        },
        [pscustomobject]@{
            Name = 'PUR'
            Description = 'Purchase orders'
            Query = @"
select
    [PayerID],
    [SupplierID],
    [DocumentDate],
    [PONumber],
    [HeaderRefNo],
    [BuyerContact],
    [BuyerEmail],
    [BuyerApproverPrev],
    [BuyerApproverNext],
    [LineNo],
    [LineRefNo1],
    [LineRefNo2],
    [BuyerProductCode],
    [ProductDescription],
    [OrderedQty],
    [OrderedQtyUOM],
    [NetPrice],
    [PerQty],
    [ReceivedQty],
    [CostedQty],
    [ReceivedValue],
    [CostedValue],
    [LineValueExclGST],
    [LineGSTRate],
    [LineGSTValue],
    [Currency]
from PlusOnePUR
order by [PONumber], [ORD]
"@
            Columns = @(
                'PayerID',
                'SupplierID',
                'DocumentDate',
                'PONumber',
                'HeaderRefNo',
                'BuyerContact',
                'BuyerEmail',
                'BuyerApproverPrev',
                'BuyerApproverNext',
                'LineNo',
                'LineRefNo1',
                'LineRefNo2',
                'BuyerProductCode',
                'ProductDescription',
                'OrderedQty',
                'OrderedQtyUOM',
                'NetPrice',
                'PerQty',
                'ReceivedQty',
                'CostedQty',
                'ReceivedValue',
                'CostedValue',
                'LineValueExclGST',
                'LineGSTRate',
                'LineGSTValue',
                'Currency'
            )
            TrimValues = $true
            GetFileName = {
                param ([datetime]$date)
                return 'PUR-GAP-{0}.csv' -f $date.ToString('yyMMdd')
            }
        }
    )
}

function Resolve-ExtractionDefinitions {
    param (
        [Parameter(Mandatory = $true)]
        [object[]]$Definitions,

        [string[]]$RequestedExtractions
    )

    if (-not $RequestedExtractions -or ($RequestedExtractions | Where-Object { $_ -ieq 'All' })) {
        return $Definitions
    }

    $definitionsByName = @{}
    foreach ($definition in $Definitions) {
        $definitionsByName[$definition.Name.ToUpperInvariant()] = $definition
    }

    $selected = @()
    foreach ($requested in $RequestedExtractions) {
        $key = $requested.ToUpperInvariant()
        if (-not $definitionsByName.ContainsKey($key)) {
            $available = @('All') + ($Definitions | ForEach-Object { $_.Name })
            throw "Extraction '$requested' is not defined. Available extractions: $($available -join ', ')."
        }
        $selected += $definitionsByName[$key]
    }

    return $selected
}

function ConvertTo-CsvField {
    param (
        [AllowNull()]
        [object]$Value
    )

    if ($null -eq $Value -or $Value -eq [DBNull]::Value) {
        $text = ''
    }
    elseif ($Value -is [System.IFormattable]) {
        $text = $Value.ToString($null, [System.Globalization.CultureInfo]::InvariantCulture)
    }
    else {
        $text = [string]$Value
    }

    return '"' + $text.Replace('"', '""') + '"'
}

function ConvertTo-CsvLine {
    param (
        [AllowEmptyCollection()]
        [object[]]$Values
    )

    return (($Values | ForEach-Object { ConvertTo-CsvField -Value $_ }) -join ',')
}

function Export-SqlQueryToCsv {
    param (
        [Parameter(Mandatory = $true)]
        [string]$ConnectionString,

        [Parameter(Mandatory = $true)]
        [string]$Query,

        [Parameter(Mandatory = $true)]
        [string[]]$Columns,

        [Parameter(Mandatory = $true)]
        [string]$OutputPath,

        [int]$CommandTimeout = 120,

        [bool]$TrimValues = $false
    )

    $connection = New-Object System.Data.SqlClient.SqlConnection($ConnectionString)
    $command = $connection.CreateCommand()
    $command.CommandText = $Query
    $command.CommandTimeout = $CommandTimeout
    $reader = $null
    $writer = New-Object System.IO.StreamWriter($OutputPath, $false, [System.Text.Encoding]::UTF8)
    $rowCount = 0

    try {
        $writer.WriteLine((ConvertTo-CsvLine -Values $Columns))

        $connection.Open()
        $reader = $command.ExecuteReader()
        while ($reader.Read()) {
            $values = foreach ($column in $Columns) {
                $value = $reader[$column]
                if ($TrimValues -and $null -ne $value -and $value -ne [DBNull]::Value) {
                    ([string]$value).Trim()
                }
                else {
                    $value
                }
            }
            $writer.WriteLine((ConvertTo-CsvLine -Values $values))
            $rowCount++
        }

        return $rowCount
    }
    finally {
        if ($reader) { $reader.Close(); $reader.Dispose() }
        $writer.Close()
        $writer.Dispose()
        $command.Dispose()
        $connection.Close()
        $connection.Dispose()
    }
}

function Invoke-PlusOneExtraction {
    param (
        [Parameter(Mandatory = $true)]
        $Definition,

        [Parameter(Mandatory = $true)]
        $SiteConfig,

        [Parameter(Mandatory = $true)]
        [datetime]$RunDate
    )

    if (-not $SiteConfig.LocalUploadPath) {
        throw "LocalUploadPath is not defined for site '$Site'."
    }
    if (-not $SiteConfig.SqlConnectionString) {
        throw "SqlConnectionString is not defined for site '$Site'."
    }

    $fileName = & $Definition.GetFileName $RunDate
    $outputPath = Join-Path -Path $SiteConfig.LocalUploadPath -ChildPath $fileName

    Write-Log "Extracting '$($Definition.Name)' to '$outputPath'."
    if ($WhatIf) {
        Write-Log "WhatIf mode: not writing '$outputPath'."
        return
    }

    if (-not (Test-Path $SiteConfig.LocalUploadPath)) {
        New-Item -ItemType Directory -Path $SiteConfig.LocalUploadPath | Out-Null
    }

    $commandTimeout = if ($SiteConfig.SqlCommandTimeout) { [int]$SiteConfig.SqlCommandTimeout } else { 120 }
    $trimValues = if ($Definition.PSObject.Properties.Name -contains 'TrimValues') { [bool]$Definition.TrimValues } else { $false }
    $rowCount = Export-SqlQueryToCsv -ConnectionString $SiteConfig.SqlConnectionString -Query $Definition.Query -Columns $Definition.Columns -OutputPath $outputPath -CommandTimeout $commandTimeout -TrimValues $trimValues
    Write-Log "Extracted '$($Definition.Name)' with $rowCount row(s) to '$outputPath'."
}

try {
    $siteConfig = Load-Config
    $global:CurrentSite = $siteConfig
    $global:LogFilePath = if ($siteConfig.ExtractLogFilePath) { $siteConfig.ExtractLogFilePath } elseif ($siteConfig.UploadLogFilePath) { $siteConfig.UploadLogFilePath } else { $siteConfig.LogFilePath }

    Write-Log "Starting PlusOne extraction for site '$Site'."

    $definitions = Get-ExtractionDefinitions
    $selectedDefinitions = Resolve-ExtractionDefinitions -Definitions $definitions -RequestedExtractions $Extraction
    foreach ($definition in $selectedDefinitions) {
        Invoke-PlusOneExtraction -Definition $definition -SiteConfig $siteConfig -RunDate $RunDate
    }

    Write-Log "Completed PlusOne extraction for site '$Site'."
}
catch {
    Write-Log "Fatal error: $($_.Exception.Message)" -Level 'ERROR'
    throw
}
