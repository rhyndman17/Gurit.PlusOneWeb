<#
.SYNOPSIS
    Download PlusOne files for AU site.
.DESCRIPTION
    Convenience wrapper that calls PlusOne-Download-Import.ps1 with AU site parameter.
#>

$scriptDir = if ($PSCommandPath) { Split-Path -Parent $PSCommandPath } elseif ($PSScriptRoot) { $PSScriptRoot } elseif ($MyInvocation.MyCommand.Path) { Split-Path -Parent $MyInvocation.MyCommand.Path } else { throw 'Cannot determine script directory.' }
& (Join-Path $scriptDir 'PlusOne-Download-Import.ps1') -Site AU
