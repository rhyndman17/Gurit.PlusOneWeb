<#
.SYNOPSIS
    Download PlusOne CSV files from SFTP and import into GP invoice staging tables.
.DESCRIPTION
    Connects to NZ or AU PlusOne SFTP, downloads CSV files to the local UNC download folder, validates the CSV contents, bulk inserts line rows into the split PlusOne staging tables, and moves files into archive folders.
.NOTES
    Requires WinSCP. Install WinSCP and ensure WinSCP.com is available in PATH or in the script folder.
#>

[CmdletBinding()]
param (
    [Parameter(Mandatory = $true, Position = 0)]
    [ValidateSet('NZ', 'AU')]
    [string]$Site,

    [switch]$WhatIf
)

$ErrorActionPreference = 'Stop'

function Write-Log {
    param (
        [Parameter(Mandatory = $true)]
        [string]$Message,

        [ValidateSet('INFO','WARN','ERROR')]
        [string]$Level = 'INFO'
    )

    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = "[$timestamp] [$Level] $Message"
    Write-Host $line

    if ($global:LogFilePath) {
        $line | Out-File -FilePath $global:LogFilePath -Append -Encoding UTF8
    }
}

function Load-Config {
    $scriptDir = if ($PSCommandPath) { Split-Path -Parent $PSCommandPath } elseif ($PSScriptRoot) { $PSScriptRoot } elseif ($MyInvocation.MyCommand.Path) { Split-Path -Parent $MyInvocation.MyCommand.Path } else { throw 'Cannot determine script directory.' }
    $configFile = Join-Path $scriptDir 'PlusOneConfig.json'
    if (-not (Test-Path $configFile)) {
        throw "Configuration file not found: $configFile"
    }

    $json = Get-Content -Path $configFile -Raw | ConvertFrom-Json
    if (-not $json.Sites.$Site) {
        throw "Site '$Site' is not defined in configuration."
    }

    $siteConfig = $json.Sites.$Site
    $properties = @(
        'LocalDownloadPath',
        'DownloadArchivePath',
        'LogFilePath',
        'RemoteDownloadDirectory',
        'RemoteDownloadFilter',
        'SqlConnectionString',
        'SqlCommandTimeout',
        'SqlBulkInsertTimeout'
    )
    foreach ($prop in $properties) {
        while ($siteConfig.$prop -is [array]) {
            $siteConfig.$prop = $siteConfig.$prop[0]
        }
    }

    return $siteConfig
}

function Get-WinSCPExePath {
    $candidates = @(
        (Join-Path -Path $PSScriptRoot -ChildPath 'WinSCP.com'),
        (Join-Path -Path $PSScriptRoot -ChildPath 'WinSCP.exe'),
        'WinSCP.com',
        'C:\Program Files\WinSCP\WinSCP.com',
        'C:\Program Files (x86)\WinSCP\WinSCP.com'
    )
    foreach ($candidate in $candidates) {
        if (Test-Path $candidate) {
            return (Get-Item $candidate).FullName
        }
    }
    $command = Get-Command WinSCP.com -ErrorAction SilentlyContinue
    if ($command) {
        return $command.Source
    }
    throw 'WinSCP.com was not found. Install WinSCP or place WinSCP.com in PATH or the script folder.'
}

function Get-WinSCPOpenCommand {
    param ($siteConfig)
    $user = $siteConfig.Username
    $sftpHost = $siteConfig.SftpHost
    $port = $siteConfig.SftpPort
    $password = $siteConfig.Password.Replace('"', '""')
    $hostKey = $siteConfig.HostKeyFingerprint

    return 'open sftp://' + $user + '@' + $sftpHost + ':' + $port + '/ -hostkey="' + $hostKey + '" -password="' + $password + '"'
}

function ConvertTo-WinSCPQuotedArgument {
    param (
        [AllowEmptyString()]
        [string]$value
    )

    return '"' + $value.Replace('"', '""') + '"'
}

function Invoke-WinSCPScript {
    param (
        [string[]]$ScriptLines,
        [string]$logFilePath
    )

    $winSCPExe = Get-WinSCPExePath
    $scriptFile = Join-Path $env:TEMP "WinSCPScript_$([guid]::NewGuid()).txt"
    Set-Content -Path $scriptFile -Value (($ScriptLines | ForEach-Object { [string]$_ }) -join [Environment]::NewLine) -Encoding ASCII

    try {
        $arguments = '/script="' + $scriptFile + '" /log="' + $logFilePath + '" /ini=nul'
        $processInfo = New-Object System.Diagnostics.ProcessStartInfo
        $processInfo.FileName = $winSCPExe
        $processInfo.Arguments = $arguments
        $processInfo.RedirectStandardOutput = $true
        $processInfo.RedirectStandardError = $true
        $processInfo.UseShellExecute = $false
        $processInfo.CreateNoWindow = $true

        $process = New-Object System.Diagnostics.Process
        $process.StartInfo = $processInfo
        $process.Start() | Out-Null
        $stdout = $process.StandardOutput.ReadToEnd()
        $stderr = $process.StandardError.ReadToEnd()
        $process.WaitForExit()

        if ($process.ExitCode -ne 0) {
            throw "WinSCP failed with exit code $($process.ExitCode). STDOUT: $stdout STDERR: $stderr"
        }

        return $stdout
    }
    finally {
        if (Test-Path $scriptFile) { Remove-Item $scriptFile -Force }
    }
}

function Download-RemoteFiles {
    param (
        [string]$remoteDirectory,
        [string]$remoteFilter,
        [string]$localDirectory,
        $siteConfig
    )

    $logFile = Join-Path $env:TEMP "WinSCP_Download_$([guid]::NewGuid()).log"
    $lcdCommand = 'lcd {0}' -f (ConvertTo-WinSCPQuotedArgument -value $localDirectory)
    $cdCommand = 'cd {0}' -f (ConvertTo-WinSCPQuotedArgument -value $remoteDirectory)
    $getCommand = 'get -delete -transfer=binary {0}' -f (ConvertTo-WinSCPQuotedArgument -value $remoteFilter)

    $scriptLines = @(
        'option batch on',
        'option confirm off',
        (Get-WinSCPOpenCommand -siteConfig $siteConfig),
        $lcdCommand,
        $cdCommand,
        $getCommand,
        'exit'
    )

    Invoke-WinSCPScript -ScriptLines $scriptLines -logFilePath $logFile | Out-Null
}

function Try-ParsePlusOneDate {
    param (
        [AllowEmptyString()]
        [string]$value,

        [Parameter(Mandatory = $true)]
        [ref]$parsedDate
    )

    $formats = [string[]]@('yyyyMMdd', 'yyyy-MM-dd', 'MM/dd/yyyy')
    $candidate = [datetime]::MinValue
    $success = [datetime]::TryParseExact(
        [string]$value,
        $formats,
        [System.Globalization.CultureInfo]::InvariantCulture,
        [System.Globalization.DateTimeStyles]::None,
        [ref]$candidate
    )

    if ($success) {
        $parsedDate.Value = $candidate
    }

    return $success
}

function Limit-Text {
    param (
        [AllowNull()]
        [object]$Value,

        [Parameter(Mandatory = $true)]
        [int]$MaxLength,

        [Parameter(Mandatory = $true)]
        [string]$ColumnName,

        [hashtable]$TruncationCounts
    )

    if ($null -eq $Value -or $Value -eq [DBNull]::Value) {
        return ''
    }

    $text = [string]$Value
    if ($text.Length -le $MaxLength) {
        return $text
    }

    if ($TruncationCounts) {
        if ($TruncationCounts.ContainsKey($ColumnName)) {
            $TruncationCounts[$ColumnName] = [int]$TruncationCounts[$ColumnName] + 1
        }
        else {
            $TruncationCounts[$ColumnName] = 1
        }
    }

    return $text.Substring(0, $MaxLength)
}

function Parse-PlusOneCsv {
    param ([string]$path)

    $expectedHeaders = @(
        'GLDimension1', 'GLDimension2', 'SupplierID', 'DocumentDate', 'AccountingValueDate',
        'DocumentNo', 'ImageURL', 'LedgerCode', 'LineValueExclGST', 'LineValueGST',
        'LineDescription', 'PurchaseOrderNo', 'PurchaseOrderLineNo', 'InvoicedQty', 'GLDimension3'
    )

    $csv = Import-Csv -Path $path -ErrorAction Stop
    $actualHeaders = if ($csv.Count -gt 0) {
        $csv[0].PSObject.Properties.Name
    }
    else {
        Get-Content -Path $path -First 1 -ErrorAction Stop | ConvertFrom-Csv | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name
    }

    $missingHeaders = $expectedHeaders | Where-Object { $_ -notin $actualHeaders }
    if ($missingHeaders) {
        throw "CSV header mismatch. Missing columns: $($missingHeaders -join ', ')"
    }

    $rows = [System.Collections.Generic.List[PSObject]]::new()
    $errors = [System.Collections.Generic.List[string]]::new()
    $rowNumber = 1

    foreach ($row in $csv) {
        $rowNumber++
        $rowIssues = [System.Collections.Generic.List[string]]::new()

        if (-not $row.SupplierID) { $rowIssues.Add('SupplierID is required.') }
        if (-not $row.DocumentNo) { $rowIssues.Add('DocumentNo is required.') }
        if (-not $row.LedgerCode) { $rowIssues.Add('LedgerCode is required.') }

        $documentDate = [datetime]::MinValue
        if (-not [string]::IsNullOrWhiteSpace($row.DocumentDate)) {
            if (-not (Try-ParsePlusOneDate -value $row.DocumentDate -parsedDate ([ref]$documentDate))) {
                $rowIssues.Add("DocumentDate '$($row.DocumentDate)' is invalid.")
            }
        }
        else {
            $rowIssues.Add('DocumentDate is required.')
        }

        $accountingDate = [datetime]::MinValue
        if (-not [string]::IsNullOrWhiteSpace($row.AccountingValueDate)) {
            if (-not (Try-ParsePlusOneDate -value $row.AccountingValueDate -parsedDate ([ref]$accountingDate))) {
                $rowIssues.Add("AccountingValueDate '$($row.AccountingValueDate)' is invalid.")
            }
        }
        else {
            $rowIssues.Add('AccountingValueDate is required.')
        }

        $lineValueExclGST = 0.0
        if (-not [double]::TryParse($row.LineValueExclGST, [ref]$lineValueExclGST)) {
            $rowIssues.Add("LineValueExclGST '$($row.LineValueExclGST)' is invalid.")
        }

        $lineValueGST = 0.0
        if (-not [double]::TryParse($row.LineValueGST, [ref]$lineValueGST)) {
            $rowIssues.Add("LineValueGST '$($row.LineValueGST)' is invalid.")
        }

        $poLine = 0
        if (-not [string]::IsNullOrWhiteSpace($row.PurchaseOrderLineNo)) {
            if (-not [int]::TryParse($row.PurchaseOrderLineNo, [ref]$poLine)) {
                $rowIssues.Add("PurchaseOrderLineNo '$($row.PurchaseOrderLineNo)' is invalid.")
            }
        }

        $invoicedQty = 0.0
        if (-not [double]::TryParse($row.InvoicedQty, [ref]$invoicedQty)) {
            $rowIssues.Add("InvoicedQty '$($row.InvoicedQty)' is invalid.")
        }

        if ($rowIssues.Count -gt 0) {
            $errors.Add("Line ${rowNumber}: $($rowIssues -join ' ')" )
            continue
        }

        $rows.Add([PSCustomObject]@{
            SourceLineNo = $rowNumber
            GLDimension1 = $row.GLDimension1.Trim()
            GLDimension2 = $row.GLDimension2.Trim()
            SupplierID = $row.SupplierID.Trim()
            DocumentDate = $documentDate
            AccountingValueDate = $accountingDate
            DocumentNo = $row.DocumentNo.Trim().ToUpperInvariant()
            ImageURL = $row.ImageURL.Trim()
            LedgerCode = $row.LedgerCode.Trim()
            LineValueExclGST = $lineValueExclGST
            LineValueGST = $lineValueGST
            LineDescription = $row.LineDescription.Trim()
            PurchaseOrderNo = $row.PurchaseOrderNo.Trim()
            POLine = $poLine
            InvoicedQty = $invoicedQty
            GLDimension3 = $row.GLDimension3.Trim()
        })
    }

    return @{ Rows = $rows; Errors = $errors }
}

function New-LineDataTable {
    $table = New-Object System.Data.DataTable
    $columns = @(
        @{ Name = 'ImportBatchID'; Type = [guid] },
        @{ Name = 'SourceLineNo'; Type = [int] },
        @{ Name = 'GLDimension1'; Type = [string] },
        @{ Name = 'GLDimension2'; Type = [string] },
        @{ Name = 'SupplierID'; Type = [string] },
        @{ Name = 'DocumentDate'; Type = [datetime] },
        @{ Name = 'AccountingValueDate'; Type = [datetime] },
        @{ Name = 'DocumentNo'; Type = [string] },
        @{ Name = 'ImageURL'; Type = [string] },
        @{ Name = 'FileName'; Type = [string] },
        @{ Name = 'LedgerCode'; Type = [string] },
        @{ Name = 'LineValueExclGST'; Type = [decimal] },
        @{ Name = 'LineValueGST'; Type = [decimal] },
        @{ Name = 'UnitValueExclGST'; Type = [decimal] },
        @{ Name = 'UnitValueGST'; Type = [decimal] },
        @{ Name = 'LineDescription'; Type = [string] },
        @{ Name = 'PurchaseOrderNo'; Type = [string] },
        @{ Name = 'POLine'; Type = [int] },
        @{ Name = 'InvoicedQty'; Type = [decimal] },
        @{ Name = 'GLDimension3'; Type = [string] }
    )

    foreach ($col in $columns) {
        $column = New-Object -TypeName System.Data.DataColumn -ArgumentList $col.Name, $col.Type
        $table.Columns.Add($column) | Out-Null
    }

    return ,$table
}

function Get-SqlCommandTimeout {
    param ($siteConfig)

    if ($siteConfig.SqlCommandTimeout) {
        return [int]$siteConfig.SqlCommandTimeout
    }

    if ($siteConfig.SqlBulkInsertTimeout) {
        return [int]$siteConfig.SqlBulkInsertTimeout
    }

    return 120
}

function Invoke-StageImportedBatch {
    param (
        [Parameter(Mandatory = $true)] [System.Data.SqlClient.SqlConnection]$Connection,
        [Parameter(Mandatory = $true)] [System.Data.SqlClient.SqlTransaction]$Transaction,
        [Parameter(Mandatory = $true)] [guid]$ImportBatchId,
        [Parameter(Mandatory = $true)] $siteConfig
    )

    $command = $Connection.CreateCommand()
    $command.Transaction = $Transaction
    $command.CommandText = 'dbo.hmlPlusOneStageImportedBatch'
    $command.CommandType = [System.Data.CommandType]::StoredProcedure
    $command.CommandTimeout = Get-SqlCommandTimeout -siteConfig $siteConfig
    $parameter = $command.Parameters.Add('@ImportBatchID', [System.Data.SqlDbType]::UniqueIdentifier)
    $parameter.Value = $ImportBatchId
    $command.ExecuteNonQuery() | Out-Null
}

function Import-IntoStaging {
    param (
        [Parameter(Mandatory=$true)] [System.Collections.Generic.List[PSObject]]$rows,
        [Parameter(Mandatory=$true)] [string]$fileName,
        [Parameter(Mandatory=$true)] $siteConfig
    )

    $table = New-LineDataTable
    $truncationCounts = @{}
    $importBatchId = [guid]::NewGuid()

    foreach ($row in $rows) {
        $dataRow = $table.NewRow()
        $dataRow.ImportBatchID = $importBatchId
        $dataRow.SourceLineNo = [int]$row.SourceLineNo
        $dataRow.GLDimension1 = Limit-Text -Value $row.GLDimension1 -MaxLength 20 -ColumnName 'GLDimension1' -TruncationCounts $truncationCounts
        $dataRow.GLDimension2 = Limit-Text -Value $row.GLDimension2 -MaxLength 20 -ColumnName 'GLDimension2' -TruncationCounts $truncationCounts
        $dataRow.SupplierID = Limit-Text -Value $row.SupplierID -MaxLength 15 -ColumnName 'SupplierID' -TruncationCounts $truncationCounts
        $dataRow.DocumentDate = $row.DocumentDate
        $dataRow.AccountingValueDate = $row.AccountingValueDate
        $dataRow.DocumentNo = Limit-Text -Value $row.DocumentNo -MaxLength 21 -ColumnName 'DocumentNo' -TruncationCounts $truncationCounts
        $dataRow.ImageURL = Limit-Text -Value $row.ImageURL -MaxLength 200 -ColumnName 'ImageURL' -TruncationCounts $truncationCounts
        $dataRow.FileName = Limit-Text -Value $fileName -MaxLength 200 -ColumnName 'FileName' -TruncationCounts $truncationCounts
        $dataRow.LedgerCode = Limit-Text -Value $row.LedgerCode -MaxLength 50 -ColumnName 'LedgerCode' -TruncationCounts $truncationCounts
        $dataRow.LineValueExclGST = [decimal]$row.LineValueExclGST
        $dataRow.LineValueGST = [decimal]$row.LineValueGST
        $dataRow.UnitValueExclGST = [decimal]0
        $dataRow.UnitValueGST = [decimal]0
        $dataRow.LineDescription = Limit-Text -Value $row.LineDescription -MaxLength 30 -ColumnName 'LineDescription' -TruncationCounts $truncationCounts
        $dataRow.PurchaseOrderNo = Limit-Text -Value $row.PurchaseOrderNo -MaxLength 20 -ColumnName 'PurchaseOrderNo' -TruncationCounts $truncationCounts
        $dataRow.POLine = [int]$row.POLine
        $dataRow.InvoicedQty = [decimal]$row.InvoicedQty
        $dataRow.GLDimension3 = Limit-Text -Value $row.GLDimension3 -MaxLength 50 -ColumnName 'GLDimension3' -TruncationCounts $truncationCounts
        $table.Rows.Add($dataRow) | Out-Null
    }

    foreach ($columnName in ($truncationCounts.Keys | Sort-Object)) {
        Write-Log "Truncated $($truncationCounts[$columnName]) value(s) for '$columnName' to match dbo.hmlPlusOneInvoiceLine column length." -Level 'WARN'
    }

    if (-not $siteConfig.SqlConnectionString) {
        throw "SqlConnectionString is not defined for site '$Site'."
    }

    $connectionString = [string]$siteConfig.SqlConnectionString
    $bulkCopyTimeout = if ($siteConfig.SqlBulkInsertTimeout) { [int]$siteConfig.SqlBulkInsertTimeout } else { 120 }
    $invoiceCount = @($rows | Group-Object -Property SupplierID, DocumentNo).Count
    $connection = $null
    $transaction = $null
    $bulkCopy = $null

    try {
        $connection = New-Object System.Data.SqlClient.SqlConnection($connectionString)
        $connection.Open()
        $transaction = $connection.BeginTransaction()

        $bulkCopy = New-Object System.Data.SqlClient.SqlBulkCopy($connection, [System.Data.SqlClient.SqlBulkCopyOptions]::Default, $transaction)
        $bulkCopy.DestinationTableName = 'dbo.hmlPlusOneInvoiceLine'
        $bulkCopy.BatchSize = 500
        $bulkCopy.BulkCopyTimeout = $bulkCopyTimeout

        foreach ($col in $table.Columns) {
            $bulkCopy.ColumnMappings.Add($col.ColumnName, $col.ColumnName) | Out-Null
        }

        Write-Log "Bulk inserting $($table.Rows.Count) line row(s) from '$fileName' into dbo.hmlPlusOneInvoiceLine."
        $bulkCopy.WriteToServer($table)

        Invoke-StageImportedBatch -Connection $connection -Transaction $transaction -ImportBatchId $importBatchId -siteConfig $siteConfig
        $transaction.Commit()
    }
    catch {
        if ($transaction) {
            try {
                $transaction.Rollback()
            }
            catch {
                Write-Log "Rollback failed for import batch '$importBatchId': $($_.Exception.Message)" -Level 'WARN'
            }
        }
        throw
    }
    finally {
        if ($bulkCopy) {
            $bulkCopy.Close()
        }
        if ($transaction) {
            $transaction.Dispose()
        }
        if ($connection) {
            $connection.Close()
            $connection.Dispose()
        }
    }

    return [PSCustomObject]@{
        ImportBatchId = $importBatchId
        InvoiceCount = $invoiceCount
        LineCount = $table.Rows.Count
    }
}

function Insert-Message {
    param (
        [Parameter(Mandatory=$true)] [string]$messageId,
        [Parameter(Mandatory=$true)] [string]$detail1,
        [string]$detail2 = '',
        [int]$messageState = 1
    )

    $detailDesc1 = Limit-Text -Value $detail1 -MaxLength 100 -ColumnName 'DetailDesc1'
    $detailDesc2 = Limit-Text -Value $detail2 -MaxLength 100 -ColumnName 'DetailDesc2'
    $messageString1 = Limit-Text -Value $detail1 -MaxLength 255 -ColumnName 'MessageString1'
    $messageString2 = Limit-Text -Value $detail2 -MaxLength 255 -ColumnName 'MessageString2'

    $sql = @"
INSERT INTO dbo.hmlPlusOneMessages (MessageDateTime, DetailDesc1, DetailDesc2, MessageID, MessageState, MessageString1, MessageString2)
VALUES (GETDATE(), @DetailDesc1, @DetailDesc2, @MessageID, @MessageState, @MessageString1, @MessageString2)
"@

    $connectionString = $global:CurrentSite.SqlConnectionString
    $connection = New-Object System.Data.SqlClient.SqlConnection($connectionString)
    $command = $connection.CreateCommand()
    $command.CommandText = $sql
    $command.Parameters.Add((New-Object System.Data.SqlClient.SqlParameter('@DetailDesc1',[System.Data.SqlDbType]::Char,100))).Value = $detailDesc1
    $command.Parameters.Add((New-Object System.Data.SqlClient.SqlParameter('@DetailDesc2',[System.Data.SqlDbType]::Char,100))).Value = $detailDesc2
    $command.Parameters.Add((New-Object System.Data.SqlClient.SqlParameter('@MessageString1',[System.Data.SqlDbType]::Char,255))).Value = $messageString1
    $command.Parameters.Add((New-Object System.Data.SqlClient.SqlParameter('@MessageString2',[System.Data.SqlDbType]::Char,255))).Value = $messageString2
    $command.Parameters.Add((New-Object System.Data.SqlClient.SqlParameter('@MessageID',[System.Data.SqlDbType]::Char,10))).Value = $messageId
    $command.Parameters.Add((New-Object System.Data.SqlClient.SqlParameter('@MessageState',[System.Data.SqlDbType]::Int))).Value = $messageState

    $connection.Open()
    $command.ExecuteNonQuery() | Out-Null
    $connection.Close()
}

function Move-ImportedFile {
    param (
        [Parameter(Mandatory=$true)] [string]$sourcePath,
        [Parameter(Mandatory=$true)] [string]$archiveRoot,
        [Parameter(Mandatory=$true)] [string]$status
    )

    $subfolder = if ($status -eq 'Success') { 'Success' } else { 'Failed' }
    $targetDir = Join-Path $archiveRoot $subfolder
    if (-not (Test-Path $targetDir)) { New-Item -ItemType Directory -Path $targetDir | Out-Null }

    $targetFile = Join-Path $targetDir ([IO.Path]::GetFileName($sourcePath))
    if (Test-Path $targetFile) {
        $targetFile = Join-Path $targetDir ("$([IO.Path]::GetFileNameWithoutExtension($sourcePath))_$(Get-Date -Format 'yyyyMMddHHmmss')$([IO.Path]::GetExtension($sourcePath))")
    }

    Move-Item -Path $sourcePath -Destination $targetFile -Force
    Write-Log "Moved '$sourcePath' to '$targetFile'." -Level INFO
}

function Process-File {
    param ([string]$filePath)

    $fileName = [IO.Path]::GetFileName($filePath)
    Write-Log "Processing downloaded file: $fileName"

    $parseResult = Parse-PlusOneCsv -Path $filePath
    if ($parseResult.Errors.Count -gt 0) {
        $errorMessage = "Validation failed for '$fileName': $($parseResult.Errors -join ' | ')"
        Write-Log $errorMessage -Level 'ERROR'
        Insert-Message -messageId 'CSVERR' -detail1 $fileName -detail2 $errorMessage -messageState 9
        Move-ImportedFile -sourcePath $filePath -archiveRoot $global:CurrentSite.DownloadArchivePath -status 'Failed'
        return
    }

    try {
        $stageResult = Import-IntoStaging -rows $parseResult.Rows -fileName $fileName -siteConfig $global:CurrentSite
        Write-Log "Import succeeded for '$fileName'. Batch $($stageResult.ImportBatchId) staged $($stageResult.InvoiceCount) invoice(s) and $($stageResult.LineCount) line(s)." -Level 'INFO'
        Insert-Message -messageId 'IMPORT' -detail1 $fileName -detail2 "Imported to staging successfully. Batch $($stageResult.ImportBatchId)" -messageState 0
        Move-ImportedFile -sourcePath $filePath -archiveRoot $global:CurrentSite.DownloadArchivePath -status 'Success'
    }
    catch {
        $failure = $_.Exception.Message
        $position = if ($_.InvocationInfo -and $_.InvocationInfo.PositionMessage) { " $($_.InvocationInfo.PositionMessage)" } else { '' }
        $stackTrace = if ($_.ScriptStackTrace) { " Stack: $($_.ScriptStackTrace)" } else { '' }
        Write-Log "SQL import failed for '$fileName': $failure$position$stackTrace" -Level 'ERROR'
        Insert-Message -messageId 'SQLERR' -detail1 $fileName -detail2 $failure -messageState 9
        Move-ImportedFile -sourcePath $filePath -archiveRoot $global:CurrentSite.DownloadArchivePath -status 'Failed'
    }
}

try {
    $siteConfig = Load-Config
    $global:CurrentSite = $siteConfig
    $global:LogFilePath = $siteConfig.LogFilePath

    Write-Log "Starting PlusOne download/import for site '$Site'."

    if (-not (Test-Path $siteConfig.LocalDownloadPath)) {
        New-Item -ItemType Directory -Path $siteConfig.LocalDownloadPath | Out-Null
    }

    Download-RemoteFiles -remoteDirectory $siteConfig.RemoteDownloadDirectory -remoteFilter $siteConfig.RemoteDownloadFilter -localDirectory $siteConfig.LocalDownloadPath -siteConfig $siteConfig

    $downloadedFiles = Get-ChildItem -Path $siteConfig.LocalDownloadPath -Filter $siteConfig.RemoteDownloadFilter -File -ErrorAction Stop | Sort-Object LastWriteTime
    if (-not $downloadedFiles -or $downloadedFiles.Count -eq 0) {
        Write-Log "No files were downloaded to '$($siteConfig.LocalDownloadPath)' matching '$($siteConfig.RemoteDownloadFilter)'."
        return
    }

    foreach ($file in $downloadedFiles) {
        Process-File -filePath $file.FullName
    }

    Write-Log "Completed PlusOne download/import for site '$Site'."
}
catch {
    Write-Log "Fatal error: $($_.Exception.Message)" -Level 'ERROR'
    if ($global:CurrentSite) {
        Insert-Message -messageId 'FATAL' -detail1 $Site -detail2 $_.Exception.Message -messageState 9
    }
    throw
}
finally {
    # No persistent SFTP session cleanup needed when using WinSCP command-line.
}
