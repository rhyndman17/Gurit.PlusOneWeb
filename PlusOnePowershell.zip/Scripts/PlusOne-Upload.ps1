<#
.SYNOPSIS
    Upload local PlusOne files to the PlusOne SFTP inbound folder.
.DESCRIPTION
    Scans the configured local upload folder for NZ or AU, uploads matching files to the remote inbound directory, logs progress, and archives uploaded files.
.NOTES
    Requires WinSCP. Install WinSCP and ensure WinSCP.com is available in PATH or in the script folder.
#>

[CmdletBinding()]
param (
    [Parameter(Mandatory = $true, Position = 0)]
    [ValidateSet('NZ', 'AU')]
    [string]$Site,

    [switch]$WhatIf
)

$ErrorActionPreference = 'Stop'

function Write-Log {
    param (
        [Parameter(Mandatory = $true)]
        [string]$Message,

        [ValidateSet('INFO','WARN','ERROR')]
        [string]$Level = 'INFO'
    )

    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $entry = "[$timestamp] [$Level] $Message"
    Write-Host $entry
    if ($global:LogFilePath) {
        $entry | Out-File -FilePath $global:LogFilePath -Append -Encoding UTF8
    }
}

function Load-Config {
    $scriptDir = if ($PSCommandPath) { Split-Path -Parent $PSCommandPath } elseif ($PSScriptRoot) { $PSScriptRoot } elseif ($MyInvocation.MyCommand.Path) { Split-Path -Parent $MyInvocation.MyCommand.Path } else { throw 'Cannot determine script directory.' }
    $configFile = Join-Path $scriptDir 'PlusOneConfig.json'
    if (-not (Test-Path $configFile)) {
        throw "Configuration file not found: $configFile"
    }

    $json = Get-Content -Path $configFile -Raw | ConvertFrom-Json
    if (-not $json.Sites.$Site) {
        throw "Site '$Site' is not defined in configuration."
    }

    $siteConfig = $json.Sites.$Site

    # Ensure properties are strings, not arrays (handle nested arrays)
    $properties = @('LocalUploadPath', 'RemoteUploadDirectory', 'RemoteUploadFilter', 'UploadArchivePath', 'SftpHost', 'Username', 'Password', 'HostKeyFingerprint')
    foreach ($prop in $properties) {
        while ($siteConfig.$prop -is [array]) {
            $siteConfig.$prop = $siteConfig.$prop[0]
        }
    }

    return $siteConfig
}

function Get-WinSCPExePath {
    $candidates = @(
        (Join-Path -Path $PSScriptRoot -ChildPath 'WinSCP.com'),
        (Join-Path -Path $PSScriptRoot -ChildPath 'WinSCP.exe'),
        'WinSCP.com',
        'C:\Program Files\WinSCP\WinSCP.com',
        'C:\Program Files (x86)\WinSCP\WinSCP.com'
    )
    foreach ($candidate in $candidates) {
        if (Test-Path $candidate) {
            return (Get-Item $candidate).FullName
        }
    }
    $command = Get-Command WinSCP.com -ErrorAction SilentlyContinue
    if ($command) {
        return $command.Source
    }
    throw 'WinSCP.com was not found. Install WinSCP or place WinSCP.com in PATH or the script folder.'
}

function Get-WinSCPOpenCommand {
    param ($siteConfig)
    $user = $siteConfig.Username
    $sftpHost = $siteConfig.SftpHost
    $port = $siteConfig.SftpPort
    $password = $siteConfig.Password.Replace('"', '""')
    $hostKey = $siteConfig.HostKeyFingerprint

    return 'open sftp://' + $user + '@' + $sftpHost + ':' + $port + '/ -hostkey="' + $hostKey + '" -password="' + $password + '"'
}

function ConvertTo-WinSCPQuotedArgument {
    param (
        [AllowEmptyString()]
        [string]$value
    )

    return '"' + $value.Replace('"', '""') + '"'
}

function Invoke-WinSCPScript {
    param (
        [string[]]$ScriptLines,
        [string]$logFilePath
    )

    $winSCPExe = Get-WinSCPExePath
    $scriptFile = Join-Path $env:TEMP "WinSCPScript_$([guid]::NewGuid()).txt"
    Set-Content -Path $scriptFile -Value (($ScriptLines | ForEach-Object { [string]$_ }) -join [Environment]::NewLine) -Encoding ASCII

    try {
        $arguments = '/script="' + $scriptFile + '" /log="' + $logFilePath + '" /ini=nul'
        $processInfo = New-Object System.Diagnostics.ProcessStartInfo
        $processInfo.FileName = $winSCPExe
        $processInfo.Arguments = $arguments
        $processInfo.RedirectStandardOutput = $true
        $processInfo.RedirectStandardError = $true
        $processInfo.UseShellExecute = $false
        $processInfo.CreateNoWindow = $true

        $process = New-Object System.Diagnostics.Process
        $process.StartInfo = $processInfo
        $process.Start() | Out-Null
        $stdout = $process.StandardOutput.ReadToEnd()
        $stderr = $process.StandardError.ReadToEnd()
        $process.WaitForExit()

        if ($process.ExitCode -ne 0) {
            throw "WinSCP failed with exit code $($process.ExitCode). STDOUT: $stdout STDERR: $stderr"
        }

        return $stdout
    }
    finally {
        if (Test-Path $scriptFile) { Remove-Item $scriptFile -Force }
    }
}

function Get-UploadFiles {
    param (
        [string]$uploadPath,
        [string]$fileFilter
    )

    if (-not (Test-Path $uploadPath)) {
        throw "Upload folder does not exist: $uploadPath"
    }

    return Get-ChildItem -Path $uploadPath -Filter $fileFilter -File -ErrorAction Stop | Sort-Object LastWriteTime
}

function Upload-LocalFile {
    param (
        [string]$localPath,
        [string]$remoteDirectory,
        $siteConfig
    )

    $remoteDirectory = $remoteDirectory.TrimEnd('/')
    $remoteFile = [IO.Path]::GetFileName($localPath)
    $remotePath = "$remoteDirectory/$remoteFile"

    Write-Log "Uploading '$localPath' to '$remotePath'."
    if ($WhatIf) {
        Write-Log "WhatIf mode: not actually uploading '$localPath'."
        return
    }

    $logFile = Join-Path $env:TEMP "WinSCP_Upload_$([guid]::NewGuid()).log"
    $localArgument = ConvertTo-WinSCPQuotedArgument -value $localPath
    $remoteArgument = ConvertTo-WinSCPQuotedArgument -value ($remoteDirectory + '/')
    $putCommand = 'put -transfer=binary {0} {1}' -f $localArgument, $remoteArgument

    $scriptLines = @(
        'option batch on',
        'option confirm off',
        (Get-WinSCPOpenCommand -siteConfig $siteConfig),
        $putCommand,
        'exit'
    )

    Invoke-WinSCPScript -ScriptLines $scriptLines -logFilePath $logFile | Out-Null
}

function Move-UploadedFile {
    param (
        [Parameter(Mandatory = $true)]
        [string]$sourcePath,
        [Parameter(Mandatory = $true)]
        [string]$archiveRoot,
        [Parameter(Mandatory = $true)]
        [string]$status
    )

    if ($archiveRoot -is [array]) {
        $archiveRoot = $archiveRoot[0]
    }

    $subfolder = if ($status -eq 'Success') { 'Success' } else { 'Failed' }
    $targetDir = Join-Path $archiveRoot $subfolder
    if (-not (Test-Path $targetDir)) {
        New-Item -ItemType Directory -Path $targetDir | Out-Null
    }

    $targetFile = Join-Path $targetDir ([IO.Path]::GetFileName($sourcePath))
    if (Test-Path $targetFile) {
        $targetFile = Join-Path $targetDir ("$([IO.Path]::GetFileNameWithoutExtension($sourcePath))_$(Get-Date -Format 'yyyyMMddHHmmss')$([IO.Path]::GetExtension($sourcePath))")
    }

    Move-Item -Path $sourcePath -Destination $targetFile -Force
    Write-Log "Moved '$sourcePath' to '$targetFile'."
}

function Insert-Message {
    param (
        [Parameter(Mandatory=$true)]
        [string]$messageId,
        [Parameter(Mandatory=$true)]
        [string]$detail1,
        [string]$detail2 = '',
        [int]$messageState = 1
    )

    $detail1 = $detail1.Substring(0, [Math]::Min(100, $detail1.Length))
    $detail2 = $detail2.Substring(0, [Math]::Min(100, $detail2.Length))

    $sql = @"
INSERT INTO dbo.hmlPlusOneMessages (MessageDateTime, DetailDesc1, DetailDesc2, MessageID, MessageState, MessageString1, MessageString2)
VALUES (GETDATE(), @Detail1, @Detail2, @MessageID, @MessageState, @Detail1, @Detail2)
"@

    $connectionString = $global:CurrentSite.SqlConnectionString
    $connection = New-Object System.Data.SqlClient.SqlConnection($connectionString)
    $command = $connection.CreateCommand()
    $command.CommandText = $sql
    $command.Parameters.Add((New-Object System.Data.SqlClient.SqlParameter('@Detail1',[System.Data.SqlDbType]::Char,100))).Value = $detail1
    $command.Parameters.Add((New-Object System.Data.SqlClient.SqlParameter('@Detail2',[System.Data.SqlDbType]::Char,100))).Value = $detail2
    $command.Parameters.Add((New-Object System.Data.SqlClient.SqlParameter('@MessageID',[System.Data.SqlDbType]::Char,10))).Value = $messageId
    $command.Parameters.Add((New-Object System.Data.SqlClient.SqlParameter('@MessageState',[System.Data.SqlDbType]::Int))).Value = $messageState

    $connection.Open()
    $command.ExecuteNonQuery() | Out-Null
    $connection.Close()
}

try {
    $siteConfig = Load-Config
    $global:CurrentSite = $siteConfig
    $global:LogFilePath = if ($siteConfig.UploadLogFilePath) { $siteConfig.UploadLogFilePath } else { $siteConfig.LogFilePath }

    Write-Log "Starting PlusOne upload for site '$Site'."

    $uploadFiles = Get-UploadFiles -uploadPath $siteConfig.LocalUploadPath -fileFilter $siteConfig.RemoteUploadFilter
    if (-not $uploadFiles -or $uploadFiles.Count -eq 0) {
        Write-Log "No upload files found in '$($siteConfig.LocalUploadPath)' matching '$($siteConfig.RemoteUploadFilter)'."
        return
    }

    foreach ($file in $uploadFiles) {
        try {
            Upload-LocalFile -localPath $file.FullName -remoteDirectory $siteConfig.RemoteUploadDirectory -siteConfig $siteConfig
            Insert-Message -messageId 'UPLOAD' -detail1 $file.Name -detail2 'Upload succeeded.' -messageState 0
            Move-UploadedFile -sourcePath $file.FullName -archiveRoot $siteConfig.UploadArchivePath -status 'Success'
        }
        catch {
            $errorMessage = $_.Exception.Message
            Write-Log "Upload failed for '$($file.FullName)': $errorMessage" -Level 'ERROR'
            Insert-Message -messageId 'UPLOADERR' -detail1 $file.Name -detail2 $errorMessage -messageState 9
            Move-UploadedFile -sourcePath $file.FullName -archiveRoot $siteConfig.UploadArchivePath -status 'Failed'
        }
    }

    Write-Log "Completed PlusOne upload for site '$Site'."
}
catch {
    Write-Log "Fatal error: $($_.Exception.Message)" -Level 'ERROR'
    if ($global:CurrentSite) {
        Insert-Message -messageId 'FATAL' -detail1 $Site -detail2 $_.Exception.Message -messageState 9
    }
    throw
}
finally {
    # No persistent SFTP session to clean up when using WinSCP command-line.
}
