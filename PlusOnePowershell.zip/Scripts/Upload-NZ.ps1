<#
.SYNOPSIS
    Upload PlusOne files for NZ site.
.DESCRIPTION
    Convenience wrapper that calls PlusOne-Upload.ps1 with NZ site parameter.
#>

$scriptDir = if ($PSCommandPath) { Split-Path -Parent $PSCommandPath } elseif ($PSScriptRoot) { $PSScriptRoot } elseif ($MyInvocation.MyCommand.Path) { Split-Path -Parent $MyInvocation.MyCommand.Path } else { throw 'Cannot determine script directory.' }
& (Join-Path $scriptDir 'PlusOne-Upload.ps1') -Site NZ
