<#
.SYNOPSIS
    Extract PlusOne upload files for NZ site.
.DESCRIPTION
    Convenience wrapper that calls PlusOne-Extract.ps1 with NZ site parameter.
#>

param (
    [string[]]$Extraction = @('All'),
    [datetime]$RunDate = (Get-Date),
    [switch]$WhatIf
)

$scriptDir = if ($PSCommandPath) { Split-Path -Parent $PSCommandPath } elseif ($PSScriptRoot) { $PSScriptRoot } elseif ($MyInvocation.MyCommand.Path) { Split-Path -Parent $MyInvocation.MyCommand.Path } else { throw 'Cannot determine script directory.' }
$parameters = @{
    Site = 'NZ'
    Extraction = $Extraction
    RunDate = $RunDate
}
if ($WhatIf) {
    $parameters.WhatIf = $true
}

& (Join-Path $scriptDir 'PlusOne-Extract.ps1') @parameters
